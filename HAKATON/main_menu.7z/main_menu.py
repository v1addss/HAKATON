import sys
import subprocess
from PyQt6.QtWidgets import (
    QApplication, QWidget, QPushButton, QVBoxLayout, QLabel, QCheckBox,
    QMessageBox, QComboBox, QDialog, QLineEdit, QHBoxLayout, QRadioButton, QButtonGroup
)
from PyQt6.QtGui import QFont, QColor
from PyQt6.QtCore import Qt


class SettingsDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Настройки")
        self.setGeometry(300, 300, 350, 250)

        self.layout = QVBoxLayout()

        # ===== ТЕМА =====
        self.theme_label = QLabel("Тема интерфейса:")
        self.theme_combo = QComboBox()
        self.theme_combo.addItems(["Светлая", "Серая", "Темная"])
        self.theme_combo.currentTextChanged.connect(self.change_theme)
        self.layout.addWidget(self.theme_label)
        self.layout.addWidget(self.theme_combo)

        # ===== ЯРКОСТЬ =====
        self.brightness_label = QLabel("Яркость экрана (0-100):")
        self.brightness_input = QLineEdit()
        self.brightness_input.setPlaceholderText("Например, 75")
        self.layout.addWidget(self.brightness_label)
        self.layout.addWidget(self.brightness_input)

        # ===== УПРАВЛЕНИЕ =====
        self.control_label = QLabel("Управление:")
        self.wasd_radio = QRadioButton("Клавиши W, A, S, D")
        self.arrows_radio = QRadioButton("Стрелочки ← ↑ ↓ →")
        self.wasd_radio.setChecked(True)
        self.control_group = QButtonGroup()
        self.control_group.addButton(self.wasd_radio)
        self.control_group.addButton(self.arrows_radio)

        self.layout.addWidget(self.control_label)
        self.layout.addWidget(self.wasd_radio)
        self.layout.addWidget(self.arrows_radio)

        # ===== КНОПКА СОХРАНИТЬ =====
        self.save_button = QPushButton("Сохранить настройки")
        self.save_button.clicked.connect(self.save_settings)
        self.layout.addWidget(self.save_button)

        self.setLayout(self.layout)

        # Доступ к темам
        self.themes = {
            "Светлая": "background-color: white; color: black;",
            "Серая": "background-color: #aaaaaa; color: black;",
            "Темная": "background-color: black; color: white;"
        }

    def change_theme(self, theme_name):
        if theme_name in self.themes:
            self.setStyleSheet(self.themes[theme_name])

    def save_settings(self):
        theme = self.theme_combo.currentText()
        brightness = self.brightness_input.text()
        control = "WASD" if self.wasd_radio.isChecked() else "Arrows"

        # Валідація яскравості
        try:
            brightness_value = int(brightness)
            if not (0 <= brightness_value <= 100):
                raise ValueError
        except ValueError:
            QMessageBox.warning(self, "Ошибка", "Введите корректное значение яркости от 0 до 100.")
            return

        # Показ збережених налаштувань
        QMessageBox.information(
            self, "Настройки сохранены",
            f"🎨 Тема: {theme}\n💡 Яркость: {brightness}%\n🎮 Управление: {control}"
        )
        self.accept()


class WarningWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Предупреждение")
        self.setGeometry(200, 200, 400, 250)

        # Состояние звука
        self.sound_enabled = True

        # Макет
        layout = QVBoxLayout()

        # Надпись предупреждения
        self.label = QLabel("⚠️ Игра содержит скримеры и громкие звуки!")
        self.label.setFont(QFont("Arial", 12))
        layout.addWidget(self.label)

        # Чекбокс "Выключить звук"
        self.sound_checkbox = QCheckBox("Отключить звук")
        self.sound_checkbox.stateChanged.connect(self.toggle_sound)
        layout.addWidget(self.sound_checkbox)

        # Кнопка "Играть"
        self.play_button = QPushButton("Играть")
        self.play_button.clicked.connect(self.start_game)
        layout.addWidget(self.play_button)

        # Кнопка "Настройки"
        self.settings_button = QPushButton("Настройки")
        self.settings_button.clicked.connect(self.open_settings)
        layout.addWidget(self.settings_button)

        # Кнопка "Выйти"
        self.exit_button = QPushButton("Выйти")
        self.exit_button.clicked.connect(self.close)
        layout.addWidget(self.exit_button)

        self.setLayout(layout)

    def toggle_sound(self, state):
        self.sound_enabled = not bool(state)
        print("Звук выключен" if not self.sound_enabled else "Звук включен")

    def start_game(self):
        subprocess.Popen(["python", "game.py"])
        self.close()


    def open_settings(self):
        settings_dialog = SettingsDialog(self)
        settings_dialog.exec()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = WarningWindow()
    window.show()
    sys.exit(app.exec())
